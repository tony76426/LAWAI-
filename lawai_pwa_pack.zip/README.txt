LawAI 法詢 PWA 檔案包（給 GitHub / Render）
============================================
要做的事（最簡）
1) 把這 4 個檔案放在網站根目錄：manifest.json、sw.js、offline.html、footerlogo_192.png、footerlogo_512.png
2) 在所有主要頁面的 <head> 與 </body> 前加入對應載入碼（看下方）。
3) 部署後用 Chrome DevTools 的 Application 分頁驗證 Manifest 與 Service Worker。

載入碼（貼到你的頁面）
<!-- head 內 -->
<link rel="manifest" href="/manifest.json">
<meta name="theme-color" content="#1C2A4D">
<link rel="apple-touch-icon" href="/footerlogo_192.png">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">

<!-- body 結尾前：註冊 SW -->
<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js')
      .then(reg => console.log('SW registered', reg.scope))
      .catch(err => console.warn('SW failed', err));
  });
}
</script>

Flask（Render）需補路由讓檔案在根路徑：
from flask import send_from_directory
@app.route('/manifest.json')
def manifest():
    return send_from_directory('.', 'manifest.json', mimetype='application/json')
@app.route('/sw.js')
def sw():
    return send_from_directory('.', 'sw.js', mimetype='application/javascript')
@app.route('/offline.html')
def offline():
    return send_from_directory('.', 'offline.html', mimetype='text/html')
